voltage regulator version2.brd
