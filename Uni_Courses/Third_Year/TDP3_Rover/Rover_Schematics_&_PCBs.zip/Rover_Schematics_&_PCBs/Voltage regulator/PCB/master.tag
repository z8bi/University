voltage regulator.brd
